# Check if two words are anagrams 
# Example:
# find_anagrams("hello", "check") --> False
# find_anagrams("below", "elbow") --> True


def find_anagram(word, anagram):
    # [assignment] Add your code here
    string1 = input("Enter your first word: ")
    string2 = input("Enter your second word: ")
    
    sorted_string1 = sorted(string1)
    sorted_string2 = sorted(string2)

    if sorted(string1) == sorted(string2):
        return True
    else:
        return False
print(find_anagram("string1", "string2"))

   
